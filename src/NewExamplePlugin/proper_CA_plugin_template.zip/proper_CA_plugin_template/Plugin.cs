﻿using BepInEx;
using BepInEx.Configuration;
using GameDataEditor;
using HarmonyLib;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using UnityEngine;
using Debug = UnityEngine.Debug;


namespace $safeprojectname$
{
    [BepInPlugin(GUID, "", version)]
    [BepInProcess("ChronoArk.exe")]
    public class Plugin : BaseUnityPlugin
    {
        public const string GUID = "";
        public const string version = "1.0.0";

        private static readonly Harmony harmony = new Harmony(GUID);

        internal static BepInEx.Logging.ManualLogSource logger;

        private void Awake()
        {
            logger = Logger;
            harmony.PatchAll();
        }
		
        private void OnDestroy()
        {
            if (harmony != null)
                harmony.UnpatchSelf();
        }
				

    }
}
